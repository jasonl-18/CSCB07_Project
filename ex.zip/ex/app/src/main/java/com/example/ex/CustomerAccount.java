package com.example.ex;

public class CustomerAccount {
    private String email;
    private String pwd;
    private String idToken;

    public String getEmail() {
        return email;
    }

    public String getPwd() {
        return pwd;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getIdToken() {
        return idToken;
    }

    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }

    public CustomerAccount(){}
}
