package com.example.ex;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder>{

    private ArrayList<VenuesData> myList;
    private Context context;

    public CustomAdapter(ArrayList<VenuesData> myList){
        this.myList = myList;
        this.context = context;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items, parent, false);
        CustomViewHolder holder = new CustomViewHolder(view);
        return holder;
    }



    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.venue.setText((myList.get(position).getVenue()));
        holder.date.setText(myList.get(position).getDate());
        holder.end_time.setText(myList.get(position).getEnd_time());
        holder.start_time.setText(myList.get(position).getStart_time());
        holder.location.setText(myList.get(position).getLocation());
    }

    @Override
    public int getItemCount() {
        return myList != null ? myList.size() : 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        protected TextView date;
        protected TextView end_time;
        protected TextView location;
        protected TextView start_time;
        protected TextView venue;

        public CustomViewHolder(View view) {
            super(view);
            this.date = itemView.findViewById(R.id.item_date);
            this.end_time = itemView.findViewById(R.id.item_end_time);
            this.location = itemView.findViewById(R.id.item_location);
            this.start_time = itemView.findViewById(R.id.item_start_time);
            this.venue = itemView.findViewById(R.id.item_date);
        }
    }


}
