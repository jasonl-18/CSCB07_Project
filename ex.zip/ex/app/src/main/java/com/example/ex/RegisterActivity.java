package com.example.ex;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    private FirebaseAuth myFirebaseAuth;
    private DatabaseReference myDatabaseRef;
    private EditText myEtEmail, myEtPwd;
    private Button myBtnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        myFirebaseAuth = FirebaseAuth.getInstance();
        myDatabaseRef = FirebaseDatabase.getInstance().getReference("ex");

        myEtEmail = findViewById(R.id.et_email);
        myEtPwd = findViewById(R.id.et_pwd);
        myBtnRegister = findViewById(R.id.btn_register);

        Toolbar myToolbar = findViewById(R.id.register_toolbar);
        setSupportActionBar(myToolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        myBtnRegister.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(!myEtEmail.getText().toString().equals("") && !myEtPwd.getText().toString().equals("")){
                    String email = myEtEmail.getText().toString();
                    String pwd = myEtPwd.getText().toString();

                    myFirebaseAuth.createUserWithEmailAndPassword(email, pwd).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                FirebaseUser firebaseUser = myFirebaseAuth.getCurrentUser();
                                CustomerAccount account = new CustomerAccount();
                                account.setEmail(firebaseUser.getEmail());
                                account.setPwd(pwd);
                                account.setIdToken(firebaseUser.getUid());

                                myDatabaseRef.child("CustomerAccount").child(firebaseUser.getUid()).setValue(account);

                                Toast.makeText(RegisterActivity.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(RegisterActivity.this, "Sign Up Unsuccessful", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

            }

        });
    }
}