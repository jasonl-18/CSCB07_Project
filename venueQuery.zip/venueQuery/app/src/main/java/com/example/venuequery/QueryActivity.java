package com.example.venuequery;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class QueryActivity extends AppCompatActivity {
    private ArrayList<Venue> venuesList = new ArrayList<>();
    private RecyclerView.Adapter adapter;
    private RecyclerView recyclerView;
    private LinearLayoutManager llm;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private EditText et_venue;
    String query;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);

        venuesList = new ArrayList<>();
        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("venues");

        et_venue = findViewById(R.id.et_venue);
        Button btn_query = findViewById(R.id.btn_query);

        btn_query.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(!et_venue.getText().toString().equals("")){
                    query = et_venue.getText().toString();
                    Intent intent = new Intent(QueryActivity.this, MainActivity.class);
                    intent.putExtra("query", query);
                    startActivity(intent);
                    finish();
                }

            }
        });
    }
}