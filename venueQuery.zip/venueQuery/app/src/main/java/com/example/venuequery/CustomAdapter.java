package com.example.venuequery;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder>{

    private ArrayList<Venue> myList;
    private Context context;

    public CustomAdapter(ArrayList<Venue> myList){
        this.myList = myList;
        this.context = context;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_venue, parent, false);
        CustomViewHolder holder = new CustomViewHolder(view);
        return holder;
    }



    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.venue.setText((myList.get(position).getVenue()));
        holder.date.setText(myList.get(position).getDate());
        holder.end_time.setText(String.valueOf(myList.get(position).getEnd_time()));
        holder.start_time.setText(String.valueOf(myList.get(position).getStart_time()));
        holder.location.setText(myList.get(position).getLocation());
    }

    @Override
    public int getItemCount() {
        return myList != null ? myList.size() : 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        TextView date;
        TextView end_time;
        TextView location;
        TextView start_time;
        TextView venue;

        public CustomViewHolder(View view) {
            super(view);
            this.date = itemView.findViewById(R.id.item_date);
            this.end_time = itemView.findViewById(R.id.item_end_time);
            this.location = itemView.findViewById(R.id.item_location);
            this.start_time = itemView.findViewById(R.id.item_start_time);
            this.venue = itemView.findViewById(R.id.item_venue);
        }
    }


}
